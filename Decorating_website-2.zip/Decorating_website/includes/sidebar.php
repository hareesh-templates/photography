
      <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="home_client.php">
            <i class="fas fa-fw fa-home"></i>
            <span></span>Home
          </a>
        </li>
        </li>
        <li class="nav-item dropdown">
          <a class="nav-link dropdown-toggle" href="#" id="pagesDropdown" role="button" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
            <i class="fas fa-fw fa-mobile"></i>
            <span>Contact Us</span>
          </a>
            <div class="dropdown-menu" aria-labelledby="pagesDropdown">
            <a class="dropdown-item"><i class="fas fa-fw fa-phone"></i>09098151891</a>
          </div>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="services.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Services Offered</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="reservedstatus.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Reservation Status</span></a>
        </li>
      </ul>

      <div id="content-wrapper">

        <div class="container-fluid">

