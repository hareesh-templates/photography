<section id="banner">
				<div class="inner">
					<header>
						<h1 >GRACE's EVENT DECORATING WEBSITE</h1>
						<p>Find our finest and entertaining services. Please do explore our website!</p>
					</head>
				</div>
			</section>