<header id="header" class="alt">
				<div class="logo"><a href="home.php">Event Decorating Website</a></div>
				<a href="#menu">Menu</a>
			</header>

			<nav id="menu">
				<ul class="links">
					<li><a href="index.php">Home</a></li>
					<li><a href="about.php">About</a></li>
					<li><a href="for_reserve.php">For Reservation</a></li>
					<li><a href="others.php">Others</a></li>
				</ul>
			</nav>
