<!--header-->
<?php include('includes/header.php'); ?>
 <?php include('include/connect.php'); ?>
      <!-- Navbar Search -->

      <!-- Navbar -->
 <?php include('includes/navbar.php'); ?>     
      <!-- Sidebar -->
<?php include('includes/sidebar.php'); ?>
<?php $query = "SELECT * FROM event WHERE event_id=".$_GET['id'];
$result=mysqli_query($db,$query) or die(mysqli_error($result));
while ($row = mysqli_fetch_array($result)) {
  $a=$row['event_name'];
  $b=$row['event_id'];
}
 ?>
 <body>

    <div class="container">
      <div class="card card-register mx-auto mt-5">
        <div class="card-header">Fill up this form for Reservation</div>
        <div class="card-body">
          <form role="form" method="post" action="reserveadd.php?action=add">
            <div class="form-group">
              <div class="form-row">

                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="date" id="date_reserve" class="form-control" placeholder="Current Date" required="required" name="date_reserve">
                    <label for="date_reserve">Current Date</label>
                  </div>
                </div>
              </div>
            </div>

            <div class="form-group">
              <select name="customer_id" readonly>
                <option value="<?php echo "".$_SESSION['MEMBER_ID'];?>">
                  <?php echo "".$_SESSION['fname']." ".$_SESSION['lname'];  ?>
                </option>
              </select>
                <label for="customer_id">Customer Name</label>
              </div>
            </div>

            <div class="form-group">
              <select name="event_no" readonly>
                <option value="<?php echo $b;?>">
                  <?php echo "$a";  ?>
                </option>
              </select>
                <label for="event_no">Event Name</label>
              </div>
            </div>
            <div class="form-group">
              <div class="form-label-group">
                <input type="date" id="date_event" class="form-control" placeholder="Date of the event" required="required" name="date_event">
                <label for="date_event">Date of the Event</label>
              </div>
            </div>

            <div class="form-group">
              <div class="form-label-group">
                <input type="text" id="loc_event" class="form-control" placeholder="Location" required="required" name="loc_event">
                <label for="loc_event">Location</label>
              </div>
            </div>

            <div class="form-group">
              <div class="form-row">
              </div>
            </div>
            <button type="submit" class="btn btn-default">Save Record</button>
            <button type="reset" class="btn btn-default">Clear Entry</button>
          </form>
          <!-- Breadcrumbs-->
          

          <!-- Icon Cards-->
          

          <!-- Area Chart Example-->
         

       

        <!-- Sticky Footer -->


   

    <!-- Logout Modal-->
    <?php include('includes/logoutmodal.php'); ?>
   

    <!-- Bootstrap core JavaScript-->
    <?php include('includes/scripts.php'); ?>
