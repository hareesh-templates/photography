<?php
include('include/connect.php');
include('include/header.php');

?>

<body>
 <div class="container">
      <div class="card card-register mx-auto mt-5">
        <div class="card-header"><h3>Add new user</h3></div>
        <div class="card-body">

                        <form role="form" method="post" action="user_transaction.php?action=add">
                            
                            <div class="form-group">
                              <input class="form-control" placeholder="First Name" name="fname">
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="Last Name" name="lname">
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Email" name="email">
                            </div> 
                            <div class="form-group">
                              <input type="password" class="form-control" placeholder="Password" name="password">
                            </div> 
                            <button type="submit" class="btn btn-default">Save Record</button>
                            <button type="reset" class="btn btn-default">Clear Entry</button>


                      </form>  
                    </div>
                </div>

                </body>
                </html>
                