<?php
       include('include/connect.php');
       include('include/header.php');
       include('include/sidebar.php');

        ?>

         

          <!-- DataTables Example -->
              <!-- DataTables Example -->
            <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
                        Data Table Event <a href="event_add.php?action=add" type="button" class="btn btn-xs btn-info">Add New</a>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Event Name</th>
                      <th>Description</th>
                      <th>Price</th>
                      <th>Options</th>
                    </tr>
                  </thead>
                        <?php                  
                $query = 'SELECT * FROM event';
                    $result = mysqli_query($db, $query) or die (mysqli_error($db));
                  
                        while ($row = mysqli_fetch_assoc($result)) {
                                             
                            echo '<tr>';
                            echo '<td>'. $row['event_name'].'</td>';
                            echo '<td>'. $row['description'].'</td>';
                            echo '<td>'. $row['price'].'</td>';
                            echo '<td> <a  type="button" class="btn btn-xs btn-warning" href="event_edit.php?action=edit & id='.$row['event_id'] . '"> EDIT </a> ';
                           
                            echo '</tr> ';
                }
            ?>
        
                </table>
              </div>
            </div>
          </div>
        </div>

          <?php
          include('include/scripts.php')
          //include('include/footer.php');
          ?>
