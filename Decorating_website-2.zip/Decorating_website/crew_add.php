<?php
include('include/connect.php');
include('include/header.php');
?>


<body>
 <div class="container">
      <div class="card card-register mx-auto mt-5">
        <div class="card-header"><h3>Add new record</h3></div>
        <div class="card-body">

          <?php
$query = "SELECT * FROM department";
$result = mysqli_query($db, $query) or die (mysqli_error($db));
          ?>

                        <form role="form" method="post" action="crew_transaction.php?action=add">
                            
                            <div class="form-group">
                              <input class="form-control" placeholder="Full Name" name="name">
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="Gender" name="gender">
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Age" name="age">
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Address" name="address">
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Contact Number" name="contact_number">
                            </div>
                             <div class="form-group">
                              <input class="form-control" placeholder="Salary" name="salary">
                            </div> 
                             <div class="form-group">
                              <input class="form-control" placeholder="Hired Date" name="hire_date">
                            </div>  
                             <div class="form-group">
                               <select name="department_id">
                                <?php
                                while ($row = mysqli_fetch_array($result)):;
                                ?>
                                 <option value="<?php echo $row[0];?>">
                                   <?php echo $row[1];?>
                                 </option>
                                 <?php
                                 endwhile;
                                 ?>
                               </select>
                             </div>  
                            <button type="submit" class="btn btn-default">Save Record</button>
                            <button type="reset" class="btn btn-default">Clear Entry</button>


                      </form>  
                    </div>
                </div>

                </body>
                </html>
                