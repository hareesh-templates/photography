<?php
include('include/connect.php');
include('include/header.php');
?>

<body>
 <div class="container">
      <div class="card card-register mx-auto mt-5">
        <div class="card-header"><h3>Add new record</h3></div>
        <div class="card-body">

                        <form role="form" method="post" action="department_transaction.php?action=add">
                            
                            <div class="form-group">
                              <input class="form-control" placeholder="Department Name" name="department_name">
                            </div>
                           
                            <button type="submit" class="btn btn-default">Save Record</button>
                            <button type="reset" class="btn btn-default">Clear Entry</button>


                      </form>  
                    </div>
                </div>

                </body>
             