<?php
include('include/connect.php');
?>  
<body>
    <div class="col-lg-12">
                <?php
						$department_name = $_POST['department_name'];
					switch($_GET['action']){

						case 'add':			
								$query = "INSERT INTO department
								(department_id, department_name)
								VALUES ('Null','".$department_name."')";
								mysqli_query($db,$query)or die (mysqli_error($db));;
							
						break;
									
						}
				?>
    	<script type="text/javascript">
			alert("Successfully added.");
			window.location = "table_department.php";
		</script>
                    </div>
              </body>