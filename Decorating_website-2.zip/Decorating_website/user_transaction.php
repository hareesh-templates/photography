<?php
include('include/connect.php');
?>  
<body>
    <div class="col-lg-12">
                <?php
						$fname = $_POST['fname'];
					    $lname = $_POST['lname'];
						$email = $_POST['email'];
						$password = $_POST['password'];				
					switch($_GET['action']){
						case 'add':			
								$query = "INSERT INTO admin_user
								(user_id,fname, lname, email, password)
								VALUES ('Null','".$fname."','".$lname."','".$email."',MD5('".$password."')";
								mysqli_query($db,$query)or die (mysqli_error($db));;
							
						break;
									
						}
				?>
    	<script type="text/javascript">
			alert("Successfully added.");
			window.location = "table_users.php";
		</script>
                    </div>
              </body>