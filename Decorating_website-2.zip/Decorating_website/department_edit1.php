
<body>
<?php
			    $zz = $_POST['id'];
			    $department_name = $_POST['department_name'];
              
	   include('include/connect.php');
		
	 			$query = 'UPDATE department set department_name ="'.$department_name.'" WHERE
					department_id ="'.$zz.'"';
					$result = mysqli_query($db, $query) or die(mysqli_error($db));
							
?>	
	<script type="text/javascript">
			alert("Update Successfull.");
			window.location = "table_department.php";
		</script>
 </body>