<?php
include('include/connect.php');
?>  
<body>
    <div class="col-lg-12">
                <?php
						$event_name = $_POST['event_name'];
					    $description = $_POST['description'];
						$price = $_POST['price'];
				
					switch($_GET['action']){
						case 'add':			
								$query = "INSERT INTO event
								(event_id, event_name,description, price)
								VALUES ('Null','".$event_name."','".$description."','.$price.')";
								mysqli_query($db,$query)or die (mysqli_error($db));;
							
						break;
									
						}
				?>
    	<script type="text/javascript">
			alert("Successfully added.");
			window.location = "table_event.php";
		</script>
                    </div>
              </body>