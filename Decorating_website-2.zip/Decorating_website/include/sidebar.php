<div id="wrapper">

      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
        <li class="nav-item active">
          <a class="nav-link" href="home_admin.php">
            <i class="fas fa-fw fa-home"></i>
            <span>Home</span>
          </a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="table_crew.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Crew</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="table_customer.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Customer</span></a>
        </li>
        <li class="nav-item">
          <a class="nav-link" href="table_department.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Department</span></a>
        </li>

        <li class="nav-item">
          <a class="nav-link" href="table_users.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Users</span></a>
        </li>
      <!-- Sidebar -->
      <ul class="sidebar navbar-nav">
       <li class="nav-item">
          <a class="nav-link" href="table_event.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Events Offered</span></a>
        </li>
         <li class="nav-item">
          <a class="nav-link" href="transaction_table.php">
            <i class="fas fa-fw fa-table"></i>
            <span>Reservation</span></a>
        </li>
      </ul>
      </ul>


            <div id="content-wrapper">

        <div class="container-fluid">