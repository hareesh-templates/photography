<?php
include('include/connect.php');
include('include/header.php');
include('include/sidebar.php');
include('include/breadcrumbs.php');
include('include/scripts.php');
include('include/footer.php');
?>
