<?php
include('include/connect.php');
include('include/header.php');
?>
<body>
	<?php 
$query = 'SELECT * FROM department
              WHERE
              department_id ='.$_GET['id'];
            $result = mysqli_query($db, $query) or die(mysqli_error($db));
              while($row = mysqli_fetch_array($result))
              {   
                $zz= $row['department_id'];
                $i= $row['department_name'];
              }
              
              $id = $_GET['id'];
         
?>

            <div class="container">
      <div class="card card-register mx-auto mt-5">
        <div class="card-header"><h3>Edit record</h3></div>
        <div class="card-body">
                        <form role="form" method="post" action="department_edit1.php">
                            
                            <div class="form-group">
                                <input type="hidden" name="id" value="<?php echo $zz; ?>" />
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="Department Name" name="department_name" value="<?php echo $i; ?>">
                            </div>
                           
                            <button type="submit" class="btn btn-default">Update Record</button>
                         


                      </form>  
                    </div>
                </div>
               
</body>
</html>