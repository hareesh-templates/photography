<?php
include('include/connect.php');
?>  
                <?php

    $fname = $_POST['fname'];
    $lname = $_POST['lname'];
    $contact_number = $_POST['contact_number'];
    $address = $_POST['address'];
    $email = $_POST['email'];
    $password = $_POST['password'];
    $confirm_pass = $_POST['confirm_pass'];


    switch($_GET['action']){
                        case 'add': 

                $query = "INSERT INTO customer
                                (customer_id, fname, lname, contact_number, address, email, password)
                                VALUES ('Null', '".$fname."', '".$lname."', '.$contact_number.', '".$address."','".$email."', MD5('".$password."'))";
                                mysqli_query($db,$query)or die (mysqli_error($db));;
                            
                        break;
                                    
                        }
                ?>
        <script type="text/javascript">
            alert("Successfully added.");
            window.location = "loginclient.php";
        </script>
