
<body>
<?php
	   include('include/connect.php');
		
	 			$query = 'UPDATE transaction set status ="confirmed" WHERE transaction_id ='.$_GET['id'];
					$result = mysqli_query($db, $query) or die(mysqli_error($db));
							
?>	
	<script type="text/javascript">
			alert("Successfully Confirmed.");
			window.location = "transaction_table.php";
		</script>
 </body>