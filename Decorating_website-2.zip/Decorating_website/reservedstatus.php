<!--header-->
<?php include('connection.php'); ?>
<?php include('includes/header.php'); ?>
 
      <!-- Navbar Search -->

      <!-- Navbar -->
 <?php include('includes/navbar.php'); ?>     
      <!-- Sidebar -->
<?php include('includes/sidebar.php'); ?>
          <!-- Breadcrumbs-->
          

          <!-- Icon Cards-->
          

          <!-- Area Chart Example-->
               <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
                        Data Table Transaction

                                
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Reservation Date</th>
                      <th>Event Name</th>
                      <th>Date of Event</th>
                      <th>Location</th>
                      <th>Status</th>
                      <th>Options</th>
                    </tr>
                  </thead>
                        <?php                  
                $query = 'SELECT t.transaction_id,t.date_reserve,e.event_name,t.date_event,t.loc_event,t.status FROM transaction t,customer c,event e where e.event_id=t.event_no and c.customer_id=t.customer_id and t.customer_id=4';
                    $result = mysqli_query($db, $query) or die (mysqli_error($db));
                  
                        while ($row = mysqli_fetch_assoc($result)) {
                            //echo '<td>'. $row['trans4action_id'].'</td>';                 
                            echo '<trs>';
                            echo '<td>'. $row['date_reserve'].'</td>';
                            echo '<td>'. $row['event_name'].'</td>';
                            echo '<td>'. $row['date_event'].'</td>';
                            echo '<td>'. $row['loc_event'].'</td>';
                            echo '<td>'. $row['status'].'</td>';
                            echo '<td> <a  type="button" class="btn btn-xs btn-danger" href="transaction_del.php?type=transaction&delete & id=' . $row['transaction_id'] . '">DELETE </a> </td>';
                            echo '</tr> ';
                }
            ?>
                </table>
              </div>
            </div>
          </div>
        </div>

         

       

        <!-- Sticky Footer -->
  <?php include('includes/footer.php'); ?>

   

    <!-- Logout Modal-->
    <?php include('includes/logoutmodal.php'); ?>
   

    <!-- Bootstrap core JavaScript-->
    <?php include('includes/scripts.php'); ?>
    
