<!--header-->

<?php include('includes/header.php'); ?>
 
      <!-- Navbar Search -->

      <!-- Navbar -->
 <?php include('includes/navbar.php'); ?>     
      <!-- Sidebar -->
<?php include('includes/sidebar.php'); ?>
          <!-- Breadcrumbs-->
<?php include('includes/breadcrumbs.php'); ?>
          

          <!-- Icon Cards-->
          

          <!-- Area Chart Example-->
         

       

        <!-- Sticky Footer -->
  <?php include('includes/footer.php'); ?>

   

    <!-- Logout Modal-->
    <?php include('includes/logoutmodal.php'); ?>
   

    <!-- Bootstrap core JavaScript-->
    <?php include('includes/scripts.php'); ?>
    