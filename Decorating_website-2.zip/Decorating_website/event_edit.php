<?php
include('include/connect.php');
include('include/header.php');
?>
<body>
	<?php 
$query = 'SELECT * FROM event
              WHERE
              event_id ='.$_GET['id'];
            $result = mysqli_query($db, $query) or die(mysqli_error($db));
              while($row = mysqli_fetch_array($result))
              {   
                $zz= $row['event_id'];
                $i= $row['event_name'];
                $a=$row['description'];
                $b=$row['price'];
              }
              
              $id = $_GET['id'];
         
?>

            <div class="container">
      <div class="card card-register mx-auto mt-5">
        <div class="card-header"><h3>Edit record</h3></div>
        <div class="card-body">
                        <form role="form" method="post" action="event_edit1.php">
                            
                            <div class="form-group">
                                <input type="hidden" name="id" value="<?php echo $zz; ?>" />
                            </div>
                            <div class="form-group">
                              <input class="form-control" placeholder="Event Name" name="event_name" value="<?php echo $i; ?>">
                            </div>
                             <div class="form-group">
                             <label>Description</label>
                              <textarea class="form-control" rows="3"  name="description"><?php echo $a; ?></textarea>
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Price" name="price" value="<?php echo $b; ?>">
                            </div> 
                            <button type="submit" class="btn btn-default">Update Record</button>
                         


                      </form>  
                    </div>
                </div>
               
</body>
</html>