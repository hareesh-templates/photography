<?php
include('connection.php');
?>  
<body>
    <div class="col-lg-12">
                <?php
						$name = $_POST['name'];
					    $location = $_POST['location'];
						$message = $_POST['message'];
						
					switch($_GET['action']){
						case 'add':			
								$query = "INSERT INTO suggestion
								(sug_id,name, location, suggested)
								VALUES ('Null','".$name."','".$location."','".$message."')";
								mysqli_query($db,$query)or die (mysqli_error($db));;
							
						break;
									
						}
				?>
    	<script type="text/javascript">
			alert("Successfully sent!.");
			window.location = "contact.php";
		</script>
                    </div>
              </body>