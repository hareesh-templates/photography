<?php     
include('include/connect.php');
include('include/header.php');
include('include/sidebar.php');
//include('include/sidebar1.php');
        ?>
       
        
          <!-- DataTables Example -->
              <!-- DataTables Example -->
         
                                
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    Data Table Users
                    <a href="users_add.php?action=add" type="button" class="btn btn-xs btn-info">Add New</a>
                    <tr>
                      <th>First Name</th>
                      <th>Last Name</th>
                      <th>Email</th>
                      
                    </tr>
                  </thead>
                        <?php                  
                $query = 'SELECT * FROM admin_user';
                    $result = mysqli_query($db, $query) or die (mysqli_error($db));
                  
                        while ($row = mysqli_fetch_assoc($result)) {
                                             
                            echo '<tr>';
                            echo '<td>'. $row['fname'].'</td>';
                            echo '<td>'. $row['lname'].'</td>';
                            echo '<td>'. $row['email'].'</td>';
                            echo '</tr> ';
                }
            ?>
                </table>
              </div>
            </div>
          </div>
        </div>
<?php
include('include/scripts.php');
include('include/footer.php');

?>
  </body>

</html>
