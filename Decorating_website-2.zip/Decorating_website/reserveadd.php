<!--header-->
<?php include('includes/header.php'); ?>
 <?php include('include/connect.php'); ?>
      <!-- Navbar Search -->

      <!-- Navbar -->
 <?php include('includes/navbar.php'); ?>     
      <!-- Sidebar -->
<?php include('includes/sidebar.php'); ?>
<?php $query = "SELECT * FROM event WHERE event_id=".$_GET['id'];
$result=mysqli_query($db,$query) or die(mysqli_error($result));
while ($row = mysqli_fetch_array($result)) {
  $a=$row['event_name'];
  $b=$row['event_id'];
}
 ?>

<body>
 <div class="container">
      <div class="card card-register mx-auto mt-5">
        <div class="card-header"><h3>Fill-up this form for Reservation</h3></div>
        <div class="card-body">


                        <form role="form" method="post" action="addreserve.php?action=add">
                            
              <div class="form-group">
              <div class="form-row">
                <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="date" id="date_reserve" class="form-control" required="required" name="date_reserve">
                    <label for="date_reserve">Current Date</label>
                  </div>
              </div>
              <div class="col-md-6">
                  <div class="form-label-group">
                    <input type="date" id="date_event" class="form-control" required="required" name="date_event">
                    <label for="date_reserve">Date of Event</label>
                  </div>
              </div>
            </div>
          </div>
                            <div class="form-group">
                            	<select name="customer_id" readonly>
                                <option type="text" class="form-control" placeholder="Customer Name" name="date_reserve" required="required" value="<?php echo "".$_SESSION['MEMBER_ID'];?>"> <?php echo "".$_SESSION['fname']." ".$_SESSION['lname'];  ?>
                                </option>
                                </select>
                            </div> 
                            <div class="form-group">
                              <select name="event_no" readonly>
                              <option value="<?php echo $b;?>">
                              <?php echo "$a";  ?>
                              </option>
                              </select>
                            </div>

              <div class="form-group">
              <div class="form-label-group">
                <input type="text" id="loc_event" class="form-control" placeholder="Location" name="loc_event" required="required">
                <label for="loc_event">Location</label>
              </div>
            </div>  
                            <button type="submit" class="btn btn-default">Save Record</button>
                            <button type="reset" class="btn btn-default">Clear Entry</button>


                      </form>  
                    </div>
                </div>

                </body>
                </html>
