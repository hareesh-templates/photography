
		<!-- Header -->
		<?php include ('themes/header.php'); ?>

			

		<!-- Nav -->
		<?php include ('themes/nav.php'); ?>


		<!-- Banner -->
		<?php include ('themes/banner.php'); ?>
			

		<!-- Body -->
		<?php include ('bodies/homebody.php'); ?>
			
		<!-- Footer -->
		<?php include ('themes/footer.php'); ?>
			

		<!-- Scripts -->
		<?php include ('themes/scripts.php'); ?>
			