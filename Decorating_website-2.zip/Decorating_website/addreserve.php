<?php
include('connection.php');
?>  
                <?php
					    $date_reserve = $_POST['date_reserve'];
						$customer_id = $_POST['customer_id'];
						$event_no = $_POST['event_no'];
						$date_event = $_POST['date_event'];
						$loc_event = $_POST['loc_event'];
					switch($_GET['action']){
						case 'add':			
								$query = "INSERT INTO transaction
								(transaction_id,date_reserve,customer_id,event_no, date_event,loc_event,status)
								VALUES ('Null','".$date_reserve."','".$customer_id."','".$event_no."','".$date_event."','".$loc_event."','still pending')";
								mysqli_query($db,$query)or die (mysqli_error($db));;
							
						break;
									
						}
				?>
    	<script type="text/javascript">
			alert("Successfully sent.");
			window.location = "reservedstatus.php";
		</script>
                    </div>
              </body>7