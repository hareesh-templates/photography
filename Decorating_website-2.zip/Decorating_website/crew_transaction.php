<?php
include('include/connect.php');
?>  
<body>
    <div class="col-lg-12">
                <?php
						$name = $_POST['name'];
					    $gender = $_POST['gender'];
						$age = $_POST['age'];
						$address = $_POST['address'];
						$contact_number = $_POST['contact_number'];
						$salary = $_POST['salary'];
						$hire_date = $_POST['hire_date'];
						$department_id = $_POST['department_id'];
				
					switch($_GET['action']){
						case 'add':			
								$query = "INSERT INTO crew
								(crew_id,name, gender, age, address,contact_number, salary, hire_date, department_id)
								VALUES ('Null','".$name."','".$gender."','".$age."','".$address."','$contact_number','".$salary."','".$hire_date."','$department_id')";
								mysqli_query($db,$query)or die (mysqli_error($db));;
							
						break;
									
						}
				?>
    	<script type="text/javascript">
			alert("Successfully added.");
			window.location = "table_crew.php";
		</script>
                    </div>
              </body>