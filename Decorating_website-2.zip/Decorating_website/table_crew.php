<?php     
include('include/connect.php');
include('include/header.php');
include('include/sidebar.php');
//include('include/sidebar1.php');
        ?>
       
        
          <!-- DataTables Example -->
              <!-- DataTables Example -->
          <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
                        Data Table Crew <a href="crew_add.php?action=add" type="button" class="btn btn-xs btn-info">Add New</a>

                                
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Gender</th>
                      <th>Age</th>
                      <th>Address</th>
                      <th>Contact #</th>
                      <th>Salary</th>
                      <th>Hired date</th>
                      <th>Department Name</th>
                    </tr>
                  </thead>
                        <?php                  
                $query = 'SELECT c.crew_id,c.name,c.gender,c.age,c.address,c.contact_number,c.salary,c.hire_date,d.department_name FROM crew c, department d where d.department_id=c.department_id';
                    $result = mysqli_query($db, $query) or die (mysqli_error($db));
                  
                        while ($row = mysqli_fetch_assoc($result)) {
                                             
                            echo '<trs>';
                            echo '<td>'. $row['name'].'</td>';
                            echo '<td>'. $row['gender'].'</td>';
                            echo '<td>'. $row['age'].'</td>';
                            echo '<td>'. $row['address'].'</td>';
                            echo '<td>'. $row['contact_number'].'</td>';
                            echo '<td>'. $row['salary'].'</td>';
                            echo '<td>'. $row['hire_date'].'</td>';
                            echo '<td>'. $row['department_name'].'</td>';
                            echo '</tr> ';
                }
            ?>
                </table>
              </div>
            </div>
          </div>
        </div>
<?php
include('include/scripts.php');
include('include/footer.php');

?>
  </body>

</html>
