
<body>
<?php
			    $zz = $_POST['id'];
			    $event_name = $_POST['event_name'];
                $description =$_POST['description'];
                $price =$_POST['price'];
	   include('include/connect.php');
		
	 			$query = 'UPDATE event set event_name ="'.$event_name.'", description ="'.$description.'",
					price ="'.$price.'" WHERE
					event_id ="'.$zz.'"';
					$result = mysqli_query($db, $query) or die(mysqli_error($db));
							
?>	
	<script type="text/javascript">
			alert("Update Successfull.");
			window.location = "table_event.php";
		</script>
 </body>