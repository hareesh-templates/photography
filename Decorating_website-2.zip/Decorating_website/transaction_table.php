<?php     
include('include/connect.php');
include('include/header.php');
include('include/sidebar.php');
//include('include/sidebar1.php');
        ?>
       
        
          <!-- DataTables Example -->
              <!-- DataTables Example -->

               <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
                        Data Table Transaction

                                
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Customer Name</th>
                      <th>Reservation Date</th>
                      <th>Event Name</th>
                      <th>Date of Event</th>
                      <th>Location</th>
                      <th>Status</th>
                      <th>Options</th>
                    </tr>
                  </thead>
                        <?php                  
                $query = 'SELECT t.transaction_id,concat(c.fname," ",c.lname)as "fullname",t.date_reserve,e.event_name,t.date_event,t.loc_event,t.status FROM transaction t,customer c,event e where c.customer_id=t.customer_id and e.event_id=t.event_no';
                    $result = mysqli_query($db, $query) or die (mysqli_error($db));
                  
                        while ($row = mysqli_fetch_assoc($result)) {
                            //echo '<td>'. $row['transaction_id'].'</td>';                 
                            echo '<trs>';
                            echo '<td>'. $row['fullname'].'</td>';
                            echo '<td>'. $row['date_reserve'].'</td>';
                            echo '<td>'. $row['event_name'].'</td>';
                            echo '<td>'. $row['date_event'].'</td>';
                            echo '<td>'. $row['loc_event'].'</td>';
                            echo '<td>'. $row['status'].'</td>';
                            echo '<td> <a  type="button" class="btn btn-xs btn-warning" href="transaction_edit1.php?action=edit & id='.$row['transaction_id'] . '"> CONFIRM </a> ';
                            echo '<td> <a  type="button" class="btn btn-xs btn-danger" href="transaction_edit.php?action=edit & id='.$row['transaction_id'] . '"> CANCEL </a> ';
                            echo '</tr> ';
                }
            ?>
                </table>
              </div>
            </div>
          </div>
<?php

include('include/scripts.php');

?>
  </body>

</html>
