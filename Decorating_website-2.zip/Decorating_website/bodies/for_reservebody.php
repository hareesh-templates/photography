
		<!-- Main -->
			<div id="main">

				<!-- Section -->
					<section class="wrapper">
						<div class="inner">
							<header class="align-center">
								<h1>For Reservation</h1>
							</header>
							                <h4>For Registration</h4>
							                <p>Please create an account to access reservation.</p>
											<div class="3u 12u$(small)">
												<ul class="actions vertical">
													<li><a href="registration.php" class="button fit">Register</a></li></ul>
											</div>
											<h4>To Log In</h4>
											<p>If you already had an account, you could directly log-in to your account</p>
											<div class="3u 12u$(small)">
												<ul class="actions vertical">
													<li><a href="loginclient.php" class="button fit">Log-in</a></li>
												</ul>
											</div>
											</div>
										</div>

						</div>
					</section>


						<!-- Elements -->


									<!-- Table -->
										
									
									<!-- Image -->


						</div>
					</div>
				</section>

				<!-- Section -->
				

