
		<!-- Main -->
			<div id="main">

				<!-- Section -->
					<section class="wrapper">
						<div class="inner">
							<header class="align-center">
								<h1>ABOUT</h1>
							</header>
							<div class="flex flex-2">
								<div class="col col2">
									<h3>Dear readers</h3>
									<p>This website was made for the conviniency of the customers on finding designers and decoration experts which they could directly access to.And this web could give a more detailed infos about our services and by exploring this web you could choose the services that you want.</p>
									<p>We'd love to entertain you there and our crews are all able to keep you company while you go deep to get more information on this site. And again thank you for visiting this site.</p>
								</div>
								<div class="col col1 first">
									<div class="image round fit">
										<a href="about.php" class="link"><img src="images/p33.jpg" alt="" /></a>
									</div>
								</div>
							</div>
						</div>
					</section>


						<!-- Elements -->


									<!-- Table -->
										
									
									<!-- Image -->

								  <h3 class="center-line">Some images of our Decoration</h3>
									<span class="image fit"><img src="images/p9.jpg" alt="" /></span>
										<div class="box alt">
											<div class="row 50% uniform">
												<div class="4u"><span class="image fit"><img src="images/p55.jpg" alt="" /></span></div>
												<div class="4u"><span class="image fit"><img src="images/p11.jpg" alt="" /></span></div>
												<div class="4u$"><span class="image fit"><img src="images/p33.jpg" alt="" /></span></div>
												<!-- Break -->
												<div class="4u"><span class="image fit"><img src="images/pp1.jpg" alt="" /></span></div>
												<div class="4u"><span class="image fit"><img src="images/pp2.jpg" alt="" /></span></div>
												<div class="4u$"><span class="image fit"><img src="images/pp4.jpg" alt="" /></span></div>
											</div>
										</div>

										<h4>Set-up &amp; Content</h4>
										<p><span class="image left"><img src="images/p1.jpg" alt="" /></span>Lorem ipsum dolor sit accumsan interdum nisi, quis tincidunt felis sagittis eget. tempus euismod. Vestibulum ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu faucibus. Integer ac pellentesque praesent tincidunt felis sagittis eget. tempus euismod. Vestibulum ante ipsum primis sagittis eget. tempus euismod. Vestibulum ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu faucibus. Integer ac pellentesque praesent tincidunt felis sagittis eget. tempus euismod. Vestibulum ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu faucibus. Integer ac pellentesque praesent. Vestibulum ante ipsum primis in faucibus magna blandit adipiscing eu felis iaculis volutpat lorem ipsum dolor sit amet dolor consequat.</p>
										<p><span class="image right"><img src="images/pp3.jpg" alt="" /></span>Lorem ipsum dolor sit accumsan interdum nisi, quis tincidunt felis sagittis eget. tempus euismod. Vestibulum ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu faucibus. Integer ac pellentesque praesent tincidunt felis sagittis eget. tempus euismod. Vestibulum ante ipsum primis sagittis eget. tempus euismod. Vestibulum ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu faucibus. Integer ac pellentesque praesent tincidunt felis sagittis eget. tempus euismod. Vestibulum ante ipsum primis in faucibus vestibulum. Blandit adipiscing eu felis iaculis volutpat ac adipiscing accumsan eu faucibus. Integer ac pellentesque praesent. Vestibulum ante ipsum primis in faucibus magna blandit adipiscing eu felis iaculis volutpat lorem ipsum dolor sit amet dolor consequat.</p>
						</div>
					</div>
				</section>

				<!-- Section -->
				

