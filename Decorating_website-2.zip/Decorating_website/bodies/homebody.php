
		<!-- Main -->
			<div id="main">

				<!-- Section -->
					<section class="wrapper style1">
						<div class="inner">
							<!-- 2 Columns -->
								<div class="flex flex-2">
									<div class="col col1">
										<div class="image round fit right">
											<a href="home.php" class="link"><img src="images/p4.jpg" /></a>
										</div>
									</div>
									<div class="col col2">
										<h3>INTRODUCTION</h3>
										<p>
The purpose of this Decorating Website is to enable the owner to see how his/her business doing in a well-mannered information. Because the system could give the information of all the activities of the business with the given record of the created system, including every single detail about customer records, crew records and of course the transactions. Somehow the owner could also monitor the number of his/her crews and in which field are they in. The owner will also be able to know the salAnary given to the crews.</p>
									</div>
								</div>
						</div>
					</section>

				<!-- Section -->
					<section class="wrapper style2">
						<div class="inner">
							<div class="flex flex-2">
								<div class="col col2">
									<p> And in terms of the transactions and customers, this Decorating Website could give every information about all transactions at a given date and who were the customers involved or have transacted in that date. In this situation the owner will have the efficient hold of hints of what to do and he/she could figure out of what was going on in the business. And in order to gain good feedback, and to satisfy the customers of the services given to them, this system could provide the customer record and information, which they could choose or suggest the services that they want. And in that idea, the owner could add new events and services which could be useful and could also be applied to another customer.</p>
								</div>
								<div class="col col1 first">
									<div class="image round fit left">
										<a href="home.php" class="link"><img src="images/p2.jpg" alt="" /></a>
									</div>
								</div>
							</div>
						</div>
					</section>

