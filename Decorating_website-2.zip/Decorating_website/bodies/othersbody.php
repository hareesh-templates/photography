
		<!-- Main -->
			<div id="main">

				<!-- Section -->
					<section class="wrapper">
						<div class="inner">
							<header class="align-center">
								<h1>The Admin</h1>
							</header>
							<div class="flex flex-2">
								<div class="col col2">
									<h3>Hi there!</h3>
									<p>This website was made for the conviniency of the customers on finding designers and decoration experts which they could directly access to.And this web could give a more detailed infos about our services and by exploring this web you could choose the services that you want.</p>
									<p>We'd love to entertain you there and our crews are all able to keep you company while you go deep to get more information on this site. And again thank you for visiting this site.</p>
								</div>
								<div class="col col1 first">
									<div class="image round fit">
										<a href="about.php" class="link"><img src="images/p33.jpg" alt="" /></a>
									</div>
								</div>
							</div>
						</div>
					</section>


					<div id="main">

				<!-- Section -->
					<section class="wrapper">
						<div class="inner">
							<header class="align-center">
							</header>
					<h4>Log-In for Admin</h4>
											<div class="3u 12u$(small)">
												<ul class="actions vertical">
													<li><a href="login.php" class="button fit">Log-in</a></li>
												</ul>
											</div>


						<!-- Elements -->


									<!-- Table -->
										
									
									<!-- Image -->

								  

				<!-- Section -->
				

