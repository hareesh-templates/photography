<?php
include('include/connect.php');
include('include/header.php');
?>

<body>
 <div class="container">
      <div class="card card-register mx-auto mt-5">
        <div class="card-header"><h3>Add new record</h3></div>
        <div class="card-body">

                        <form role="form" method="post" action="event_transaction.php?action=add">
                            
                            <div class="form-group">
                              <input class="form-control" placeholder="Event Name" name="event_name">
                            </div>
                            <div class="form-group">
                             <label>Description</label>
                              <textarea class="form-control" rows="3"  name="description"></textarea>
                            </div> 
                            <div class="form-group">
                              <input class="form-control" placeholder="Price" name="price">
                            </div>
                              
                           
                            <button type="submit" class="btn btn-default">Save Record</button>
                            <button type="reset" class="btn btn-default">Clear Entry</button>


                      </form>  
                    </div>
                </div>

                </body>