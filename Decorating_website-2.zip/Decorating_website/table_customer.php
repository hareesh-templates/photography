<?php
       include('include/connect.php');
       include('include/header.php');
       include('include/sidebar.php');
       
        ?>

       
          <!-- DataTables Example -->
              <!-- DataTables Example -->
         <div class="card mb-3">
            <div class="card-header">
              <i class="fas fa-table"></i>
                        Data Table Customer

                                
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Name</th>
                      <th>Contact Number</th>
                      <th>Address</th>
                    </tr>
                  </thead>
                        <?php                  
                $query = 'SELECT customer_id, concat(fname," ",lname) as "fullname", contact_number, address FROM customer';
                    $result = mysqli_query($db, $query) or die (mysqli_error($db));
                  
                        while ($row = mysqli_fetch_assoc($result)) {
                                             
                            echo '<tr>';
                            echo '<td>'. $row['fullname'].'</td>';
                            echo '<td>'. $row['contact_number'].'</td>';
                            echo '<td>'. $row['address'].'</td>';                             
                            echo '</tr> ';
                }
            ?>
                  
                </table>
              </div>
            </div>
          </div>
        </div>

          <?php
include('include/scripts.php');
include('include/footer.php');
?>
