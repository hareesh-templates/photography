<!--header-->
<?php include('connection.php'); ?>
<?php include('includes/header.php'); ?>
  
      <!-- Navbar Search -->

      <!-- Navbar -->
 <?php include('includes/navbar.php'); ?>     
      <!-- Sidebar -->
<?php include('includes/sidebar.php'); ?>
          <!-- Breadcrumbs-->
              <!-- DataTables Example -->
            <div class="card mb-3">
            <div class="card-header">
                        <h3>SERVICES OFFERED</h3>
            <div class="card-body">
              <div class="table-responsive">
                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                  <thead>
                    <tr>
                      <th>Event Name</th>
                      <th>Description</th>
                      <th>Price</th>
                      <th>Options</th>
                    </tr>
                  </thead>
                        <?php                  
                $query = 'SELECT * FROM event';
                    $result = mysqli_query($db, $query) or die (mysqli_error($db));
                  
                        while ($row = mysqli_fetch_assoc($result)) {
                                             
                            echo '<tr>';
                            echo '<td>'. $row['event_name'].'</td>';
                            echo '<td>'. $row['description'].'</td>';
                            echo '<td>'. $row['price'].'</td>';
                            echo '<td> <a  type="button" class="btn btn-xs btn-warning" href="reserveadd.php?action=edit & id='.$row['event_id'] . '"> GET RESERVATION </a> ';
                            echo '</tr> ';
                }
            ?>
        
                </table>
              </div>
            </div>
          </div>
        </div>

          

          <!-- Icon Cards-->
          

          <!-- Area Chart Example-->
         

       

        <!-- Sticky Footer -->
  <?php include('includes/footer.php'); ?>

   

    <!-- Logout Modal-->
    <?php include('includes/logoutmodal.php'); ?>
   

    <!-- Bootstrap core JavaScript-->
    <?php include('includes/scripts.php'); ?>
    
